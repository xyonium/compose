# AGENTS.md — xyonium/compose 维护指南

本仓库集中管理 savorcare.com 体系的容器化部署栈。本文档由 dockerno1 上 Claude Code 时期
的项目 memory 迁移整编（原文归档在 [docs/claude-memory/](docs/claude-memory/)），
后续由 DSH 维护。

## 仓库结构：每项目一个 orphan 分支

- **main**：索引 README + 每项目一个同步 workflow（`sync-firecrawl.yml`、`sync-sub2api.yml`、
  `sync-authentik.yml`）。GitHub Actions 的 schedule 只在默认分支跑，所以同步任务集中在 main。
- **项目 orphan 分支**（`firecrawl`、`sub2api` …）：互相完全独立，只含该项目部署文件。

## 通用约定（所有项目分支适用）

### 三文件模式

| 文件 | 用途 | 谁来改 |
|---|---|---|
| `docker-compose.upstream.yaml` | 上游 compose 原样拷贝 | 只由同步机器人改 |
| `docker-compose.portainer.yaml` | 全部自定义（镜像 mirror、traefik、卷、健康检查放宽等） | **手改只动这个文件** |
| `docker-compose.yaml` | 机器人预合并产物（主镜像钉 digest），部署平台直接消费 | 只由机器人生成，手改会被覆盖 |

### 基础设施

- 镜像一律走私服 mirror `jcr.savorcare.com/{ghcr,docker}/`。注意：**GitHub Actions runners
  无法访问该 mirror**（只有用户主机网络可达），别设计 runner 直连 mirror 的方案。
- traefik 走外部网络 `reverse-proxy`，`*.savorcare.com` 泛域名证书，certresolver `myresolver`。
- 部署平台（Arcane / 原 Portainer CE）**没有 re-pull image**：主镜像必须钉 digest，靠 compose
  diff 驱动更新；稳定的第三方镜像浮动不钉。
- secrets 一律在部署平台的项目 env 里，**不进 git**。
- 部署平台已迁往 **Arcane**：**push ≠ 自动部署**。agent 的 ~2min 轮询只是轻量 sync，不触发部署；
  真正部署靠 GitOps sync 周期（`@every 500m` ≈ 8.3h）或在 Arcane UI 手动点 Sync。agent 消费
  预合并单文件 `docker-compose.yaml`，物化后 compose up。
- 本机直连 github.com 的 git/TLS 偶发握手失败，重试即可；api.github.com 与
  raw.githubusercontent.com 稳定。

## firecrawl 分支

自托管 firecrawl（`firecrawl.savorcare.com`）。布局：三文件 + 三个自研服务目录
（`research-proxy/`、`papers-service/`、`pdf-ocr/`，各自有 README）+ 三个镜像构建
workflow（推 `ghcr.io/xyonium/firecrawl-*`，用户命名空间 package，需给本仓库授 write）。

> 历史：本分支带 37 提交历史自旧仓库 xyonium/firecrawl 迁入（回滚链未断）。
> **旧 firecrawl 仓库将退役，一切引用以本仓库 firecrawl 分支为准。**

关键事实：

- **firecrawl-mcp 不构建自本地源码**，是上游镜像 + compose command 里 `node -e` 运行时
  patch dist（禁用云专有的 find_tools/Alexandria 引导、裁剪工具描述等 13 处删减型 patch，
  锚点漂移即静默跳过、永不 crash）。改 patch 必须遵守下面的双层验证清单。
- **rabbitmq 健康检查已放宽**：冷启动实测 ~27s，超过上游 ~20s 窗口会导致 api 停 created；
  overlay 放宽为 start_period 30s / retries 12。
- **三构建 workflow 并发撞车**：单次 push 同时改 3 个 workflow 文件会三路并发构建，pin-commit
  push 互相拒绝 → 串行 `gh run rerun <id>` 恢复即可（缓存命中，重跑很快）。
- 上游演进方向：nuq 队列引擎引入 FoundationDB 可选后端（默认 pg）；api 容器由
  harness.js 一把梭（无独立 worker 服务）。
- 研究栈（research-proxy shim 桥接 papers-service + reach-mcp(mcpo) + GitHub API；
  papers-service 替代 paper-search-mcp；pdf-ocr 转发自托管 MinerU）完整演进史与实测结论见
  [docs/claude-memory/paper-search-de-mcpo-plan.md](docs/claude-memory/paper-search-de-mcpo-plan.md)。

### mcp patch 双层验证清单（踩过两次坑，必须遵守）

firecrawl-mcp 的启动 patch 藏在 `node -e '...'` 单引号体里，改后必须两层都验：

1. **JS 逻辑层**：在钉版镜像的 dist 副本上跑 patch 片段，验证锚点唯一、ESM 语法、幂等。
2. **compose/sh 传递层**：用 `python3 yaml.safe_load` 直读 YAML 提取**完整 command 串**
   （`docker compose config` 会把字面 `$` 显示成 `$$`，不能当真实值），模拟
   `$$X→$X`、未定义 `${VAR}→空` 后再验证锚点仍匹配，最后在钉版镜像 + 全新 dist 上真实启动
   并验证 tools/list。

禁区：单引号体内**禁撇号**（can't/don't 也不行）、禁反引号；patch 锚点里任何 `${...}`
形态必须写成 `$${...}`（否则被 compose 插值清空、静默不匹配）。

## sub2api 分支

部署上游 [Wei-Shaw/sub2api](https://github.com/Wei-Shaw/sub2api)
（`https://sub2api.savorcare.com`）。三文件模式同上，另多一个机器人维护的 `.env.example`
（上游原样拷贝，查变量的权威参考）。自定义：镜像全走 mirror、摘宿主端口改走 traefik、
顶层 `name: sub2api` 固定项目名（数据卷恒为 `sub2api_*`，重建自动挂回）。
上游的 `docker-compose.local.yml`（绑定挂载变体）**刻意不跟踪**。

部署平台项目 env **必填**三个安全凭据（上游 docker-deploy.sh 原本交互生成，平台部署
没有这一步，必须自己生成）：`openssl rand -hex 32` × 3 ——
`POSTGRES_PASSWORD`（不设直接拒启动）、`JWT_SECRET`（不固定则重启后登录态全失效）、
`TOTP_ENCRYPTION_KEY`（不固定则重启后所有 2FA 失效）。明细见该分支 README 凭据表。

## netbird 分支

NetBird 全功能（VPN 管理 + Agent Network Beta）。**分支经安全清洗重建（2026-10，
单 commit 起点）**：域名、拓扑、IP、主机名一律不入库，占位域名为
`netbird.example.com`，真实域名部署时走项目 env `${NETBIRD_DOMAIN}`。三文件模式的
变体（四文件），上游同步机制与其他分支不同：

- **上游无静态 compose**：`sync-netbird.yml` source 官方 `getting-started.sh`
  （`sed` 去掉末尾 `init_environment` 入口）只调渲染函数生成文件——不起容器、不部署。
  渲染两次：option 1（外部 traefik）出 `docker-compose.upstream.yaml`；
  option 0+proxy 出完整栈，yq 提取 proxy 服务为 `docker-compose.upstream-proxy.yaml`。
  proxy 定义因此始终跟踪上游，非手抄。**渲染用占位域名**——上游产物天然脱敏；
  bot 步骤末尾有 `git grep savorcare` 总闸。
- **域名/私仓/证书路径全 env 化**：override 把上游 4 组 traefik router label 按同 key
  全覆盖为 `` Host(`${NETBIRD_DOMAIN}`) ``；4 个镜像走 `${JCR_REGISTRY}`；泛域名证书
  目录走 `${NETBIRD_CERT_DIR}`。合并产物 `--no-interpolate` 保留模板，由部署平台
  项目 env 注入。**平台项目 env 必填 5 个**：`NETBIRD_DOMAIN` / `JCR_REGISTRY` /
  `NETBIRD_CERT_DIR` / `NB_PROXY_TOKEN` / `NB_RELAY_AUTH_SECRET`（详见分支 README 凭据表）。
- **密钥外置**：`config.yaml` 三个随机密钥洗成占位符入库（上游不支持 env 展开），
  真实文件由 `scripts/bootstrap-config.py <真实域名>` 全域替换占位域名后灌
  `netbird_config` 命名卷；`NB_PROXY_TOKEN` 两阶段 bootstrap（先部署再
  `admin token create` 换真 token）。
- traefik 固定证书风格（渲染时 `NETBIRD_TRAEFIK_CERTRESOLVER=` 留空，只出 `tls=true`）；
  override 只补 web 入口 `http2https` 跳转。
- proxy 私有模式（`NB_PROXY_PRIVATE=true`）：**无任何 traefik 路由**，agent 流量走
  WireGuard 隧道直连 proxy（身份=WG 源 IP 映射）；TLS 用 `${NETBIRD_CERT_DIR}` 泛域名
  证书 bind 进 `/wildcard-certs`。ACME/pp-v2 都关闭。
- 反向哨兵是重点：合并产物不得出现 `./config.yaml` bind、内建 traefik、certresolver、
  `HostSNI(*)`、pp-v2、env_file、`NETBIRD_AGENT_NETWORK_ONLY`、任何真实域名。

## 参考档案

- [docs/claude-memory/](docs/claude-memory/) — Claude Code 时期的 4 份项目 memory 原文
  （仓库约定、firecrawl 部署体系、mcp patch 清单、paper-search 去 mcpo 计划）
- [docs/superpowers/specs/2026-09-22-compose-repo-design.md](docs/superpowers/specs/2026-09-22-compose-repo-design.md) — 本仓库初始设计稿
